import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from xiaomi_pictorial import extract_morning_records, make_base_name, MorningRecord


class ParserTests(unittest.TestCase):
    def test_prefers_full_or_high_quality(self):
        payload = {
            "items": [
                {
                    "id": "1",
                    "exparam": {"morning_date": "2026-09-23"},
                    "meta": {"title": "测试标题", "desc": "测试描述"},
                    "images": [
                        {
                            "cl_url": {
                                "url_h": "https://example.com/1080.jpg",
                                "url_full": "https://example.com/full.jpg",
                                "url_root": "https://cdn.example.com",
                                "locator": "abc/def",
                            }
                        }
                    ]
                }
            ]
        }
        record = extract_morning_records(payload)[0]
        self.assertEqual("https://example.com/full.jpg", record.image_candidates[0])
        self.assertIn("https://cdn.example.com/webp/w2160/abc/def", record.image_candidates)

    def test_name_format(self):
        record = MorningRecord(
            morning_date="2026-09-23",
            item_id="1",
            title="早安 世界",
            description="",
            image_url="",
        )
        self.assertEqual("2026-09-23", make_base_name(record, "date"))
        self.assertEqual("早安 世界", make_base_name(record, "title"))
        self.assertEqual("2026-09-23 早安 世界", make_base_name(record, "date_title"))


if __name__ == "__main__":
    unittest.main()
