# Xiaomi Pictorial

小米早安画报历史下载工具。

## 本次更新重点

1. **GUI 改成更现代的扁平风格**：引入 `ttkbootstrap`，界面更接近现代桌面工具。
2. **新增软件图标**：扁平风图片图标，包含 `assets/app_icon.png` 和 `assets/app_icon.ico`。
3. **优化图片分辨率策略**：
   - 优先尝试 `url_full`
   - 其次尝试 `url_h`
   - 再尝试按 `url_root + locator` 组合的 `2160 / 1440 / 1080` 候选地址
   - 支持 `best / 2160 / 1440 / 1080` 质量模式
4. **新增图片命名格式**：
   - `date`
   - `title`
   - `date_title`

## 运行

```bash
pip install -r requirements.txt
python xiaomi_pictorial.py
```

命令行示例：

```bash
python xiaomi_pictorial.py --start 2026-09-01 --end 2026-09-23 --quality best --name-format date_title
```
